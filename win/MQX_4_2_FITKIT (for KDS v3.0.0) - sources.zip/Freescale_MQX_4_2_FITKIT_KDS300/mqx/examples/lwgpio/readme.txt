Note: lwgpio example has been moved to gpio directory. 

The old Posix IO gpio example was removed as the driver is no longer supported.